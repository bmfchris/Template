﻿using System;

namespace ExameTemplate
{
    public class Category
    {
        public string Title { get; set; }
        public int Value { get; set; }
    }

}
