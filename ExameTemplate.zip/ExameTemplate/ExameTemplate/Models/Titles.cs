﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExameTemplate
{
    public class Titles
    {

        static public string[] GetTitles()
        {
            string[] _names = { "Up", "Down", "Left", "Right", "No Where" };

            return _names;
        }

    }
}
